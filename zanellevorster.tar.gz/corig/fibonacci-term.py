import time 
import sys  #part of python standard library (not needed in requirements.txt)
from math import log10, floor, ceil
import numpy as np

###############################################################
# N Input from user through command line
# First argument from command line will be the name of the file
# Therefore, second argument taken as input to python script 
N = int(sys.argv[1])
###############################################################

# # ********************METHOD 1***********************************
# # This method does not work for N values larger than approx 300
# # Runtime error, value is too large for 'power' in NumPy to handle
# # numbers gets too large, program runs into a state of overflow.

# digits = 0

# sqrt_five = np.sqrt(5)
# alpha = (1 + sqrt_five) / 2
# beta = (1 - sqrt_five) / 2

# index = 0

# while not digits == N:
#     index +=1
#     Fn = 1/sqrt_five*(np.power(alpha,index) - np.power(beta,index)) #Binet's formula 
#     digits = np.floor(np.log10(Fn) + 1)

# print(index)

#********************METHOD 2***********************************
# #This method CASTS variables to String (undesired in assignment instructions)
# #This is an iterative approach (Not recursion)
 
# import itertools

# def Fibs(N):
# 	digits = N
# 	a = 1  # Need it to calculate Fib sequence
# 	b = 0  #'zeroth' number in Fib sequence, when i == 0
# 	for i in itertools.count():
#     #When i == 1, then only the first Fib nr (1) is started and placed in 'b'
#     #'b' is the current number being compared to the nr. of digits. 
# 		if len(str(b)) > digits:
# 			raise RuntimeError("Not found")
# 		elif len(str(b)) == digits:
# 			return str(i)
# 		a, b = b, a + b     #calculate fib nr.

# startTime = time.time()
# print(Fibs(N))
# execTime = (time.time() - startTime)
# print('Execution time [s]' + str(execTime))

# #If N = 1000, time = 0.095996 sec
# #If N = 5000, time = 13.368 sec
# #If N = 10 000, time = 80.7042 sec

#********************METHOD 3***********************************
#Binet's formula

def fib_seq_digit(N):
    if N < 2:
        return 1

    sqrt_five = np.sqrt(5)
    phi = (1 + sqrt_five) / 2
    return ceil((N + log10(sqrt_five) - 1 )/ log10(phi))

#startTime = time.time()
print(fib_seq_digit(N))
#execTime = (time.time() - startTime)
#print('Execution time [s]' + str(execTime))

#N = 1000, time = 0.0 sec
#N = 10 000, time = 0.0 sec
#N = 100 000, time = 0.001 sec
#N = 100 000 000, time = 0.000999 sec

################################################################

#********************METHOD 4***********************************

# # Only need last two fib numbers to compute the next one
# # Nr. with 1000 digits satisfy 1e1000 <= f < 1e10001.

# #N = 1000, time = 0.001001 sec
# #N = 10 000, time = 0.05499 sec
# #N = 100 000, time = 3.47560 sec
# #N = 100 000 000, took too long. 

# def fib_of_length(n):

    # bound = 10**(n-1)   #10 to the power of n-1
    # fib = 1
    # previous_fib = 0
    # index = 1
    # while fib < bound:
    #     fib, previous_fib = fib + previous_fib, fib #Calculate fib nr. 
    #     index += 1

    # return index

    # # startTime = time.time()
#print(fib_of_length(N))
    # # execTime = (time.time() - startTime)
    # # print('Execution time [s]' + str(execTime))

