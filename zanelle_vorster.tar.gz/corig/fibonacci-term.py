# import numpy as np
import time 
import sys
from math import log10, floor, ceil

###############################################################
# First argument will be the name of the file
# Therefore, second argument taken 
N = int(sys.argv[1])
###############################################################

#********************METHOD 1***********************************
# This method does not work for N values larger than approx 300
# Runtime error, value is too large for 'power' in NumPy to handle
# # N = 10
# digits = 0

# sqrt_five = np.sqrt(5)
# alpha = (1 + sqrt_five) / 2
# beta = (1 - sqrt_five) / 2

# index = 0

# while not digits == N:
#     index +=1
#     Fn = 1/sqrt_five*(np.power(alpha,index) - np.power(beta,index)) #Binet's formula 
#     digits = np.floor(np.log10(Fn) + 1)

# print(index)

# When N is too large --> RuntimeWarning: overflow encountered in double_scalars
# numbers get too large, program runs into a state of overflow.
# When numbers are raised to powers over a certain threshold 

#********************METHOD 2***********************************

#This method CASTS variables to String (undesired)
#This is an iterative approach (Not recursion)
#If N = 1000, time = 0.095996 sec
#If N = 5000, time = 13.368 sec
#If N = 10 000, time = 80.7042 sec 
# import itertools

# def Fibs(N):
# 	digits = N
# 	a = 1  # Need it to calculate Fib sequence
# 	b = 0  #'zeroth' number in Fib sequence, when i == 0
# 	for i in itertools.count():
#     #When i == 1, then only the first Fib nr (1) is started and placed in 'b'
#     #'b' is the current number being compared to the nr. of digits. 
# 		if len(str(b)) > digits:
# 			raise RuntimeError("Not found")
# 		elif len(str(b)) == digits:
# 			return str(i)
# 		a, b = b, a + b

# N = int(input("Find index of first term with how many digits? "))
# startTime = time.time()
# print(Fibs(N))
# execTime = (time.time() - startTime)
# print('Execution time [s]' + str(execTime))

#********************METHOD 3***********************************
#Binet's formula

#Enter the term of the seq
#The result will give you the nr. of digits in that term
#Enter 45th Fib sequence nr --> Gives 10 digits. 
#Using truncation, floor.

# def fib_digits(n):
#     if n < 2:           #'Base' Case
#         return 1

#     sqrt_five = np.sqrt(5)
#     phi = (1 + sqrt_five) / 2
#     return floor(n * log10(phi) - log10(sqrt_five)) + 1 #plus 1 to whole-part of its log

# print(fib_digits(45))

#N = 1000, time = 0.0 sec
#N = 10 000, time = 0.0 sec
#N = 100 000, time = 0.001 sec
#N = 100 000 000, time = 0.000999 sec

# def fib_seq_digit(N):
#     if N < 2:
#         return 1

#     sqrt_five = np.sqrt(5)
#     phi = (1 + sqrt_five) / 2
#     return ceil((N + log10(sqrt_five) - 1 )/ log10(phi))

# #N = int(input("Find index of first term with how many digits? "))
# startTime = time.time()
# print(fib_seq_digit(N))
# execTime = (time.time() - startTime)
# print('Execution time [s]' + str(execTime))

################################################################

#********************METHOD 4***********************************

# Only need last two fib numbers to compute the next one
# Nr. with 1000 digits satisfy 1e1000 <= f < 1e10001. Therefore, compare
# two numbers instead of casting to a string and getting its length. 

#N = 1000, time = 0.001001 sec
#N = 10 000, time = 0.05499 sec
#N = 100 000, time = 3.47560
#N = 100 000 000, took too long. 

def fib_of_length(n):
    """returns index of the first fibonacci of length n digits.
       for n > 0.
    """

    bound = 10**(n-1)   #10 to the power of n
    fib = 1
    previous_fib = 0
    index = 1
    while fib < bound:
        fib, previous_fib = fib + previous_fib, fib #Calculate fib nr. 
        index += 1

    return index

#N = int(input("Term: "))
    # startTime = time.time()
print(fib_of_length(N))
    # execTime = (time.time() - startTime)
    # print('Execution time [s]' + str(execTime))

